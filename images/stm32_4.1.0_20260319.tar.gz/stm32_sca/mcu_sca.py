import argparse
# DEBUGGING
from collections import defaultdict
import json
import os
from pathlib import Path
import re
import sys
sys.path.insert(0, '..')
from sca_tool_common import DeviceModel, ExtraProps, get_sca_tool_version

# DEBUGGING
bad_det_strs = defaultdict(int)

DEFAULT_ROOT_DIR = os.path.dirname(__file__)
VERSION_PATH = Path(__file__).parent.resolve() / "VERSION"
VENDOR = "vendor"
NAME = "name"
ECOSYSTEM = "ecosystem"
TYPE_MAP = "type_map"
COMPONENTS_MAP_PREFIX = "components_map_prefix"
SDK_MAP_PREFIX = "sdk_map_prefix"
DEFAULT_SDK_COMPONENTS = "default_sdk_components"
DEPENDENT_COMPONENTS = "dependent_components"
COMPONENTS_TO_SKIP = "components_to_skip"
SUB_STRS = "sub_strs"
IS_TOOLCHAIN = "is_toolchain"
GCC = "gcc"
GENERIC = "GENERIC"
GENERIC_ONLY = "generic_only"
SDK_COMPONENT_VERSION_SYMBOL = "#"
DEFAULT_VERSION = "-"
SCA_MAP_POSTFIX = ".json"
FRAMEWORK = {
    "esp-idf": {
        VENDOR: "espressif",
        NAME: "ESP-IDF",
        ECOSYSTEM: "ESPRESSIF",
        TYPE_MAP: {"freertos_kernel": "OS"},
        COMPONENTS_MAP_PREFIX: "esp_components_map_",
        SDK_MAP_PREFIX: "esp_sdk_map_",
        DEFAULT_SDK_COMPONENTS: [],
        DEPENDENT_COMPONENTS: {},
        COMPONENTS_TO_SKIP: [GCC, "esp32"],
        SUB_STRS: None
    },
    "generic_only": {
        VENDOR: None,
        NAME: None,
        ECOSYSTEM: "GENERIC",
        TYPE_MAP: {"freertos": "OS"},
        COMPONENTS_MAP_PREFIX: None,
        SDK_MAP_PREFIX: None,
        SUB_STRS: None    
    }
}
for v in ["F1", "G0", "H5", "H7", "H7RS", "L0", "U5"]:
    name = "STM32Cube{}".format(v)
    FRAMEWORK[name.lower()] = {
        VENDOR: "st",
        NAME: name,
        ECOSYSTEM: name.upper(),
        TYPE_MAP: {"freertos": "OS"},
        COMPONENTS_MAP_PREFIX: "st_components_map_",
        SDK_MAP_PREFIX: "st_sdk_map_",
        DEFAULT_SDK_COMPONENTS: ["stm32{}xx_hal".format(v.lower()), "stm32{}xx_cmsis".format(v.lower()), "cmsis_core", "cmsis"],
        DEPENDENT_COMPONENTS: {"freertos_kernel": "cmsis_rtos2", "threadx": "cmsis_rtos2"},
        COMPONENTS_TO_SKIP: [GCC],
        SUB_STRS: {
            "LOAD ": [re.compile(r'/Middlewares/(?:Third_Party/)?ST/([^/]+)/'),
                      re.compile(r'/Middlewares/(?:Third_Party/)?([^/]+)/')]
        }
    }
FRAMEWORKS = list(FRAMEWORK.keys()) + ["generic_only"]
FRAMEWORKS.sort()
GENERIC_COMPONENTS_JSON = "generic_components_map.json"
if os.path.exists(GENERIC_COMPONENTS_JSON):
    with open(GENERIC_COMPONENTS_JSON, 'r', encoding='utf-8') as f:
        GENERIC_COMPONENTS = json.load(f)
else:
    GENERIC_COMPONENTS = {
        "arm": {
            "arm_compiler_for_embedded": {
                SUB_STRS: {
                    "arm compiler": [r' arm compiler (\d+\.\d+(?:\.\d+)*) tool']
                },
                IS_TOOLCHAIN: True
            }
        },
        "gnu": {
            "gcc": {
                SUB_STRS: {
                    "/lib/gcc/": [r'/lib/gcc/\w+[^/]*/(\d+\.\d+\.\d+)/']
                },
                IS_TOOLCHAIN: True
            }
        },
        "iar": {
            "embedded_workbench": {
                SUB_STRS: {
                    "iar elf linker": [r'#\s*iar elf linker\s*v?\s*(\d+\.\d+(?:\.\d+)*)']
                },
                IS_TOOLCHAIN: True
            }
        }
    }
    with open(GENERIC_COMPONENTS_JSON, 'w', encoding="utf8") as f:
        json.dump(GENERIC_COMPONENTS, f, ensure_ascii=False, indent=4, sort_keys=True)

for vendor in GENERIC_COMPONENTS:
    for name in GENERIC_COMPONENTS[vendor]:
        for substr in GENERIC_COMPONENTS[vendor][name][SUB_STRS]:
            compiled_regexes = []
            for regex_str in GENERIC_COMPONENTS[vendor][name][SUB_STRS][substr]:
                compiled_regexes.append(re.compile(regex_str))
            GENERIC_COMPONENTS[vendor][name][SUB_STRS][substr] = compiled_regexes


def load_components_map(prefix, components_to_skip=[]):
    """
    :return: a dict of: {<detection string>: <component name>,...} where <detection string> and <component name> are lower case
    """
    if prefix:
        components_map_file, _ = get_sca_map(prefix)
        try:
            if components_map_file and os.path.exists(components_map_file):
                print(f"Loading component map {components_map_file}...")
                with open(components_map_file, 'r', encoding='utf-8') as f:
                    components_map = json.load(f)
                    # The format of components_map is: {<detection str>: <component name>,...}
                    components_map2 = {}
                    for det_str in sorted(components_map.keys(), key=len, reverse=True):
                        if components_map[det_str].lower() in components_to_skip:
                            continue
                        det_str2 = det_str.replace("\\", "/").lower()
                        components_map2[det_str2] = components_map[det_str].lower()
                    return components_map2
        except Exception as e:
            print("ERROR: couldn't load {} - {}".format(components_map_file, e))
    return {}


def load_sdk_map(framework, prefix):
    """
    :param framework: a lower case name for the development framework, which is also a key for the FRAMEWORK dictionary i.e. "esp-idf", "stm32cubef1",...
    :return: a dict of: {<component name>: [<list of sdk versions>],...} or {}, where component names are always lower case
    """
    if prefix:
        sdk_map_file, _ = get_sca_map(prefix)
        try:
            if sdk_map_file and os.path.exists(sdk_map_file):
                print(f"Loading sdk map {sdk_map_file}...")
                with open(sdk_map_file, 'r', encoding='utf-8') as f:
                    sdk_map = json.load(f)
                    # The format of components_map is: {<SDK_NAME.lower()>: {<component name>: [<list of sdk versions>],...}}
                    if framework in sdk_map:
                        return sdk_map[framework]
        except Exception as e:
            print("ERROR: couldn't load {} - {}".format(sdk_map_file, e))
    return {}


def get_sca_map(prefix, root_dir=DEFAULT_ROOT_DIR):
    """
    Given a prefix of "esp_components_map_", find a file matching: "esp_components_map_<YYYYMMDD>.json"
    and return a tuple of ("esp_components_map_<YYYYMMDD>.json", "<YYYYMMDD>")
    """
    map_file_re = re.compile(r'^' + prefix + r'(\d{8})' + SCA_MAP_POSTFIX)
    for root, _, filenames in os.walk(root_dir):
        for filename in filenames:
            m = map_file_re.match(filename)
            if m:
                return os.path.join(root, filename), m.group(1)
        break
    print("ERROR: couldn't find map file for prefix {}!".format(prefix))
    return None, None


def detect_generic_component(line):
    for vendor in GENERIC_COMPONENTS:
        for name in GENERIC_COMPONENTS[vendor]:
            for substr in GENERIC_COMPONENTS[vendor][name][SUB_STRS]:
                if substr in line:
                    is_toolchain =  GENERIC_COMPONENTS[vendor][name][IS_TOOLCHAIN] if IS_TOOLCHAIN in GENERIC_COMPONENTS[vendor][name] else False
                    for regex in GENERIC_COMPONENTS[vendor][name][SUB_STRS][substr]:
                        m = regex.search(line)
                        if m and m.group(1):
                            return (vendor, name, m.group(1), is_toolchain)
                    return (vendor, name, None, is_toolchain)
    return None


def detect_components(line, component_map, stop_at_first_match=True):
    # :return: a set of component name strs or and empty set
    components = set()
    for det_str in component_map:
        if (det_str in line) and check_context(det_str, line):
            components.add(component_map[det_str])
            if stop_at_first_match:
                break
    return components


def check_context(det_str, line):
    # DEBUGGING
    global bad_det_strs
    # If the first or last character of det_str is NOT alphanumeric, we don't check the chars either side of the match
    if (not list(det_str)[0].isalnum()) or (not list(det_str)[-1].isalnum()):
        return True
    # Else we make sure that the characters either side of the match are NOT alphanumeric
    m = re.search(r'(?:^|/|\(|__)' + re.escape(det_str) + r'(/|\.|$)', line)
    if not m:
        bad_det_strs[det_str] += 1
        return False
    return True


def detect_components_via_regex(line, sub_strs, stop_at_first_match=False):
    """
    :param sub_strs: None or a dict such as:
        {
            "LOAD ": [re.compile(r'/Middlewares/(?:Third_Party/)?ST/([^/]+)/'),
                      re.compile(r'/Middlewares/(?:Third_Party/)?([^/]+)/')]
        }
    :return: a set of component name strs or and empty set
    """
    components = set()
    if sub_strs:
        for substr in sub_strs:
            if substr in line:
                for regex in sub_strs[substr]:
                    m = regex.search(line)
                    if m and m.group(1):
                        components.add(m.group(1))
                        if stop_at_first_match:
                            return components
    return components


def parse(map_file, sdk_version, framework):
    """
    :param map_file: the path of a map file for the build
    :param sdk_version: the version of the sdk used, or "-" if an sdk wasn't used
    :param framework: a lower case name for the development framework, which is also a key for the FRAMEWORK dictionary i.e. "esp-idf", "stm32cubef1",...
    :return: a list of lists: [[ecosystem, vendor, name, version],...]
    """
    framework_ecosystem = FRAMEWORK[framework][ECOSYSTEM]
    framework_vendor = FRAMEWORK[framework][VENDOR]

    components_map = {}
    if framework != GENERIC_ONLY:
        # a dict of: {<detection str>: <component name>,...} where <detection str> and <component name> are lower case
        components_map = load_components_map(FRAMEWORK[framework][COMPONENTS_MAP_PREFIX], components_to_skip=FRAMEWORK[framework][COMPONENTS_TO_SKIP])
    sdk_map = {}
    if sdk_version != "-":
        # a dict of: {<component name>: [<list of sdk versions>],...} or {}, where component names are always lower case
        sdk_map = load_sdk_map(framework, FRAMEWORK[framework][SDK_MAP_PREFIX])
    sub_strs = FRAMEWORK[framework][SUB_STRS]

    print("Parsing {} ...".format(map_file))
    vendor_matches = set()
    generic_matches = {} 
    toolchains = set()
    results = set()
    components_added = set()

    if sdk_version != "-":
        for component in FRAMEWORK[framework][DEFAULT_SDK_COMPONENTS]:
            components_added.add(component)
            results.add((framework_ecosystem, framework_vendor, component, SDK_COMPONENT_VERSION_SYMBOL))

    lines = set()
    with open(map_file, 'r', encoding='utf-8') as file:
        for line in file:
            line = line.strip().replace("\\", "/").lower()
            lines.add(line)
    i = 0
    total_lines = len(lines)
    for line in list(lines):
        i += 1
        print("\rProcessing line {} of {}...  ".format(i, total_lines), end = "")
        if components_map:
            vendor_matches |= detect_components(line, components_map)
        if sub_strs:
            vendor_matches |= detect_components_via_regex(line, sub_strs)
        result = detect_generic_component(line)
        if result:
            vendor, name, version, is_toolchain = result
            key = vendor + ":" + name
            if key not in generic_matches:
                generic_matches[key] = {"vendor": vendor, "name": name, "versions": set(), "is_toolchain": is_toolchain}
            if version:
                generic_matches[key]["versions"].add(version)
            if is_toolchain:
                toolchains.add("{}:{}".format(vendor, name))
    print("\n")

    if sdk_version != "-":
        for component in vendor_matches:
            if component not in components_added:
                if (component in sdk_map) and (sdk_version in sdk_map[component]):
                    components_added.add(component)
                    results.add((framework_ecosystem, framework_vendor, component, SDK_COMPONENT_VERSION_SYMBOL))
    for component in vendor_matches:
        if component not in components_added:
            components_added.add(component)
            results.add((framework_ecosystem, framework_vendor, component, DEFAULT_VERSION))
    for component in list(components_added):
        if component in FRAMEWORK[framework][DEPENDENT_COMPONENTS] and FRAMEWORK[framework][DEPENDENT_COMPONENTS][component] not in components_added:
            components_added.add(FRAMEWORK[framework][DEPENDENT_COMPONENTS][component])
            version = SDK_COMPONENT_VERSION_SYMBOL if (component in sdk_map) and (sdk_version in sdk_map[component]) else DEFAULT_VERSION
            results.add((framework_ecosystem, framework_vendor, FRAMEWORK[framework][DEPENDENT_COMPONENTS][component], version))
    
    for _, component in generic_matches.items():
        if component["name"] not in components_added:
            vendor = component["vendor"]
            name = component["name"]
            version =  DEFAULT_VERSION
            if not component["versions"]:
                print("WARNING: detected generic component {}:{}, but didn't extract version, so using a default version of {}".format(vendor, name, version))
            elif len(component["versions"]) == 1:
                version = list(component["versions"])[0]
            else:
                print("WARNING: detected multiple versions for generic component {}:{} ({}), so using a default version of {}".format(vendor, name, str(component["versions"]), version))
                version = DEFAULT_VERSION
            results.add((GENERIC, vendor, name, version))
            if component["is_toolchain"]:
                toolchains.add("{}:{}".format(vendor, name))
    
    if not toolchains:
        print("WARNING: toolchain not found!")
    elif len(toolchains) > 1:
        print("ERROR: mutliple toolchains were detected and added: {} -- please fix!".format(str(list(toolchains))))

    results = list(results)
    results.sort()
    return results


def main(firmware_vendor, firmware_name, firmware_version, framework, sdk_version, map_file, firmware_license=None, group=None):

    framework_vendor = FRAMEWORK[framework][VENDOR]
    # Note: framework will be a lower-case version of FRAMEWORK[framework][NAME]
    framework_name = FRAMEWORK[framework][NAME]
    framework_ecosystem = FRAMEWORK[framework][ECOSYSTEM]

    components = parse(map_file, sdk_version, framework)

    sdk_dependencies = []

    group = firmware_name if not group else group

    sca_tool_version = get_sca_tool_version(VERSION_PATH)
    map_datestamp = get_map_datestamp(framework)
    if map_datestamp:
        sca_tool_version += "_" + map_datestamp
    sca_tool = {"name": "mcu_sca", "version": sca_tool_version}

    default_extra_properties = {ExtraProps.SCA_TOOL: sca_tool, ExtraProps.TAGS: [group]}

    device_model = DeviceModel()

    # Add component entries (including an entry for the toolchain)
    for component in components:
        type = FRAMEWORK[framework][TYPE_MAP][component[2].lower()] if component[2].lower() in FRAMEWORK[framework][TYPE_MAP] else "LIB"
        # Note: ecosystem will be "GENERIC" for some components (such as gcc) and framework_ecosystem for the ecosystem-specific components
        ecosystem = component[0]
        vendor = component[1]
        name = component[2]
        version = component[3]
        if version == SDK_COMPONENT_VERSION_SYMBOL:
            sdk_dependencies.append([name, version])
        device_model.add_component(type, ecosystem, vendor, name, version, "", extra_properties=default_extra_properties)

    app_extra_properties = default_extra_properties.copy()
    if sdk_version != "-":
        app_extra_properties[ExtraProps.DEPENDENCIES] = [[framework_name, sdk_version]]
        # Add SDK entry
        if sdk_dependencies:
            device_model.add_component(
                "LIB", framework_ecosystem, framework_vendor, framework_name, sdk_version, "",
                extra_properties={ExtraProps.DEPENDENCIES: sdk_dependencies, ExtraProps.TAGS: [group], ExtraProps.SCA_TOOL: sca_tool})
        else:
            device_model.add_component(
                "LIB", framework_ecosystem, framework_vendor, framework_name, sdk_version, "", extra_properties=default_extra_properties)
    
    # Add firmware entry  
    device_model.add_component(
        "APP", GENERIC, firmware_vendor, firmware_name, firmware_version, firmware_license, extra_properties=app_extra_properties)

    return device_model


class MyArgumentParser(argparse.ArgumentParser):
    def error(self, _):
        raise


def get_map_datestamp(framework, root_dir=DEFAULT_ROOT_DIR):
    map_datestamp = None
    map_datestamp2 = None
    if framework in FRAMEWORK:
        if FRAMEWORK[framework][COMPONENTS_MAP_PREFIX]:
            _, map_datestamp = get_sca_map(FRAMEWORK[framework][COMPONENTS_MAP_PREFIX], root_dir=root_dir)
        if FRAMEWORK[framework][SDK_MAP_PREFIX]:
            _, map_datestamp2 = get_sca_map(FRAMEWORK[framework][SDK_MAP_PREFIX], root_dir=root_dir)
    if map_datestamp2 and ((not map_datestamp) or (map_datestamp2 > map_datestamp)):
        return map_datestamp2
    return map_datestamp


def display_version_and_exit(framework=None):
    sca_tool_version = get_sca_tool_version(VERSION_PATH)
    if framework:
        map_datestamp = get_map_datestamp(framework)
        sca_tool_version = sca_tool_version + "_" + map_datestamp if map_datestamp else sca_tool_version
    print("SCA tool for MCU development frameworks version {}".format(sca_tool_version))
    exit(1)


if __name__ == '__main__':
    try:
        arg_parser = MyArgumentParser()
        arg_parser.add_argument('-v', action='store_true')
        args = arg_parser.parse_args()
        if args.v:
            display_version_and_exit()
    except Exception as _:
        pass

    arg_parser = argparse.ArgumentParser(
        prog='SCA tool for MCU development frameworks.',
        usage=('python3 mcu_sca.py <map_file> <firmware_vendor> <firmware name> <firmware version> <framework> '
               '[--sdk_version <version>][--firmware_license <license>][--group <group tag>][-o <output file>][-v]'),
        description=('This script generates a CSV file that can be used to create a device model.'),
    )
    arg_parser.add_argument('map_file', help='The map file for the build.')
    arg_parser.add_argument('firmware_vendor', help='The firmware vendor.')
    arg_parser.add_argument('firmware_name', help='The firmware name.')
    arg_parser.add_argument('firmware_version', help='The firmware version.')
    arg_parser.add_argument('framework', help='The development framework which must be one of these: {}'.format(FRAMEWORKS))
    arg_parser.add_argument('--sdk_version', help='If you used an SDK for the framework, you should use this parameter to specify the SDK version.', default='-')
    arg_parser.add_argument('--firmware_license', help='The firmware license.')
    arg_parser.add_argument('--group', help='The group tag. By default, the firmware_name value will be used as the group.')
    arg_parser.add_argument('-o', '--output', help='The output filename or path (default is "device_model_input.csv").',
                            default='device_model_input.csv')
    arg_parser.add_argument('-v', help='Display the version of this SCA tool an exit.', action='store_true')

    args = arg_parser.parse_args()

    if args.v:
        framework = args.framework.lower() if args.framework else None
        display_version_and_exit(framework=framework)

    if not os.path.exists(args.map_file):
        print("ERROR: {} does not exist!".format(args.map_file))
        exit(1)
    framework = args.framework.lower()
    if framework not in FRAMEWORK.keys():
        print("ERROR: {} must be one of: {}".format(args.framework, list(FRAMEWORK.keys())))
        exit(1)
    if (framework == GENERIC_ONLY) and (args.sdk_version != "-"):
        print("ERROR: you cannot specify an sdk version when the framwork is {}!".format(GENERIC_ONLY))
        exit(1)

    device_model = main(args.firmware_vendor, args.firmware_name, args.firmware_version, framework, args.sdk_version,
                        args.map_file, firmware_license=args.firmware_license, group=args.group)

    device_model.output = args.output
    device_model.write_csv()

    print("\nThe SCA tool completed successfully\n")
