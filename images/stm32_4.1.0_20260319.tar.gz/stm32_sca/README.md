# Software Composition Analysis tool for the STMicroelectronics STM32 ecosystem

## Description

This tool can be used to extract data from a build map file, to generate a CSV file that can be used to create a device model.

## Prerequisites

This tool requires the following: 

- python3

## Installation

Copy the "stm32_<version>.tar.gz" archive to a location on the build host (for example to the _home_ or _tmp_ directory) and unpack it as follows:
```sh
tar -xvzf stm32_<version>.tar.gz
cd stm32_sca/
```

### Execute the STM32 SCA tool:

Run:
```sh
python3 mcu_sca.py <map_file> <firmware_vendor> <firmware_name> <firmware_version> <framework> <SDK version> [--firmware_license <license>][-o <output file>]
```
That should create "device_model_input.csv" in the current directory.

#### Notes on parameters:

_map_file_ should be the path of the map file for the build.

_firmware_name_ and _firmware_version_ should be the name and version of the built application.

_firmware_vendor_ should be the name of the software producer, which will typically be your company name.

_framework_ must be one of these: "stm32cubef1", "stm32cubeg0", "stm32cubeh5", "stm32cubeh7", "stm32cubeh7rs" or "stm32cubel0".

_SDK version_ is the version of development framework SDK (if you don't want to specify an SDK version, use "-").

_"--firmware_license &lt;license&gt;"_ can optionally be used to specify a license for the firmware.

_firmware_license_ should be a valid SPDX license identifier (see the "Identifier" columns on https://spdx.org/licenses/ and https://spdx.org/licenses/exceptions-index.html).

You can also use a comma-separated list of applicable SPDX identifiers.
The first element in the list should be the primary distribution license and can be 1 or more SPDX identifiers, separated by "OR", for example:
```sh
"Apache-2.0 OR GPL-2.0-or-later, MIT, BSD-3-Clause"
```

_"-o &lt;output file&gt;"_ can optionally be used to specify the filename or path for the output file (the default is 'device_model_input.csv').