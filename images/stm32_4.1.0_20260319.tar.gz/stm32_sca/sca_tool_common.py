import csv
import hashlib
import json
import re
import sys

maxInt = sys.maxsize
BUF_SIZE = 65536
MAX_STR_LEN = 200
# This regex just checks that the string begins with a digit and only contains valid version string characters and ends with an alphanumeric character
re_version_basic = re.compile(r'((?:\d:)?\d+[A-Za-z\d\.+~\-]*)(?<=[\dA-Za-z])')


while True:
    try:
        csv.field_size_limit(maxInt)
        break
    except OverflowError:
        maxInt = int(maxInt/10)


def get_file_info(filepath):
    """
    :return: a dict: {'path': <>, 'sha1': <>, 'sha256': <>}
    """
    try:
        # md5 = hashlib.md5()
        sha1 = hashlib.sha1()
        sha256 = hashlib.sha256()
        with open(filepath, 'rb') as f:
            while True:
                data = f.read(BUF_SIZE)
                if not data:
                    break
                # md5.update(data)
                sha1.update(data)
                sha256.update(data)
        return {'path': str(filepath), 'sha1': sha1.hexdigest(), 'sha256': sha256.hexdigest()}
    except Exception as e:
        print("Error creating file info for {}: {}".format(filepath, e))
        return {}


class ComponentType():
    """
    This is copy of secpat_sum-backend/flask/app/src/db/model/tables_layer1/component_NEW/schema.py->Component->Type
    with a few extra additions to include values defined in the CycloneDX & SPDX specs
    """
    APPLICATION = 'application'
    ARCHIVE = 'archive'
    CONTAINER = 'container'
    DATA = 'data'
    DEVICE = 'device'
    DEVICE_DRIVER = 'device-driver'
    FILE = 'file'
    FIRMWARE = 'firmware'
    FRAMEWORK = 'framework'
    HARDWARE = 'hardware'
    INSTALL = 'install'
    KERNEL = 'kernel'
    LIBRARY = 'library'
    OPERATING_SYSTEM = 'operating-system'
    OTHER = 'other'
    PATCH = 'patch'
    PLATFORM = 'platform'
    SOURCE = 'source'


class LicenseSrc():
    DECLARED_IN_METADATA = "declared_in_metadata"
    FILE_PARSED = "file_parsed"
    LOOKUP = "lookup"


class ExtraProps():
    """
    When adding values to the extra_properties dict, you should only use keys in this enum, for exmple
    if you want to add a description, you should use:
        from sca_tool_common import ExtraProps, MAX_STR_LEN
        description = "This is a description"
        extra_properties = {}
        extra_properties[ExtraProps.DESCRIPTION] = description[:MAX_STR_LEN]
    Unless otherwise stated below, the value associated with each named property should be a string with a max len of MAX_STR_LEN
    """ 
    AUTHORS = "authors"
    # datetime string. In our Component class we'll also have values of creation_date and update_date, but these refer to when
    # the class instance was created / updated, rather than the the build date for the package files.
    # We also have RELEASE_DATE, so do we just want to use that?
    BUILD_DATE = "build_date"
    COPYRIGHT = "copyright"
    # str: a comma separated list of cpe strings
    CPES = "cpes"
    # A list of lists, for packages that the current component depends_on, where each entry in the list has the format [<pkg name>, <pkg version>]
    DEPENDENCIES = "dependencies"
    # Note: if we can extract a "summary" string, we'll use that as the description
    DESCRIPTION = "description"
    DOWNLOAD_URL = "download_url"
    # A list of dicts: [{'path': <>, 'sha1': <>, 'sha256': <>},...], where each dict is typically obtained by calling get_file_info(filepath) above
    FILES = "files"
    # Generally we'll just use SUPPLIER unless the metadata specifically states "group"
    GROUP = "group"
    HOMEPAGE = "homepage"
    # See LicenseSrc enum above
    LICENSE_SRC = "license_src"
    LICENCE_URL = "license_url"
    # This is typically the installation path of the component, which might be a directory path
    # We should just choose one or more key files and add them under FILES
    # LOCATION = "location"
    MIME_TYPE = "mime_type"
    # For SPDX, if we don't have a value for "originator", we'll use the AUTHORS value
    ORIGINATOR = "originator"
    # When we're generating an SBOM for an application, there may be a primary APP component, plus a number of LIB components
    PRIMARY_COMPONENT = "primary_component"
    # The person(s) or organization(s) that published the component
    # Generally we'll just use SUPPLIER unless the metadata specifically states "publisher"
    PUBLISHER = "publisher"
    # We may want to ingest purls, but typically these will just be created in the backend (and same for swids)
    PURL = "purl"
    RELEASE_DATE = "release_date"   # datetime string
    # The version of the sca tool used
    SCA_TOOL = "sca_tool"
    SOURCE_URL = "source_url"
    # SUMMARY -- use DESCRIPTION
    # The supplier is the immediate supplier of the package (not necessarily the originator)
    # The supplier may often be the manufacturer/producer, but may also be a distributor or repackager.
    # We'll also consider GROUP and VENDOR as aliases for SUPPLIER, or should we just use VENDOR?
    SUPPLIER = "supplier"
    SWID = "swid"
    # A list of strings
    TAGS = "tags"
    # See ComponentType enum above
    TYPE = "type"
    # Generally we'll just use SUPPLIER unless the metadata specifically states "vendor"
    VENDOR = "vendor"
    # FIXME: do we really need the following 3 fields?
    NOTE = "note"
    TAG = "tag"
    PU_NUM = "pu_num"


class ComponentOld:
    def __init__(self, type, ecosystem, vendor, name, version, license, note, tag, pu_num):
        self.type = type
        self.ecosystem = ecosystem
        self.vendor = vendor
        self.name = name
        self.version = version
        self.license = license
        self.note = note
        self.tag = tag
        self.pu_num = pu_num
    
    def row(self, convert=False):
        if convert:
            extra_properties = {"note": self.note, "tag": self.tag, "pu_num": self.pu_num}
            return [self.type, self.ecosystem, self.vendor, self.name, self.version, self.license, json.dumps(extra_properties)]
        return [self.type, self.ecosystem, self.vendor, self.name, self.version, self.license, self.note, self.tag, self.pu_num]


class Component:
    def __init__(self, type, ecosystem, vendor, name, version, license, extra_properties=None):
        self.type = type
        self.ecosystem = ecosystem or ""
        self.vendor = vendor or ""
        self.name = name
        self.version = version or ""
        self.license = license or ""
        self.extra_properties = extra_properties or {}
    
    def row(self, convert=False):
        extra_properties = dict(sorted(self.extra_properties.items()))
        return [self.type, self.ecosystem, self.vendor, self.name, self.version, self.license, json.dumps(extra_properties)]


class DeviceModel:
    def __init__(self, app_name=None, app_version=None, output='device_model_input.csv', app_vendor=None, release_name=None,
                 release_version=None, license=None, description=None):
        self.app_name = app_name
        self.app_version = app_version
        self.output = output
        self.app_vendor = app_vendor
        self.release_name = release_name
        self.release_version = release_version
        self.license = license
        self.description = description
        self.components = []
        # Note: some of the values above are currently not written to the CSV and we may also add additional attributes.

    def add_component(self, *args, **kwargs):
        if ("extra_properties" in kwargs) or (len(args) == 6):
            self.components.append(Component(*args, **kwargs))
        else:
            self.components.append(ComponentOld(*args, **kwargs))

    def write_csv(self, convert=False):
        rows = [c.row(convert=convert) for c in self.components]
        if not rows:
            print("Error - cannot write device model CSV because no component rows have been added!")
            return
        rows.sort()
        print("Writing device model CSV to {}".format(self.output))
        with open(self.output, 'w+', newline='') as f:
            writer = csv.writer(f, quoting=csv.QUOTE_NONNUMERIC)
            if len(rows[0]) == 7:
                writer.writerow(['type', 'ecosystem', 'vendor', 'name', 'version', 'license', 'extra_properties'])
            else:
                writer.writerow(['type', 'ecosystem', 'vendor', 'name', 'version', 'license', 'note', 'tag', 'pu_num'])
            for row in rows:
                writer.writerow(row)

        print('Device Model completed!')

    def fix_dependencies(self):
        component_versions = {}
        for c in self.components:
            component_versions[c.name] = c.version
        for c in self.components:
            if ExtraProps.DEPENDENCIES in c.extra_properties:
                new_deps = []
                for dep in c.extra_properties[ExtraProps.DEPENDENCIES]:
                    version = None
                    if not isinstance(dep, list):
                        version = component_versions[dep] if dep in component_versions else None
                    elif len(dep) == 2:
                        version = dep[1]
                    if dep and version:
                        new_deps.append([dep, version])
                c.extra_properties[ExtraProps.DEPENDENCIES] = new_deps

    def read_csv(self, input_file):
        done = set()
        with open(input_file, 'r') as f:
            reader = csv.reader(f)
            for row in reader:
                if ((row == ['type', 'ecosystem', 'vendor', 'name', 'version', 'license', 'extra_properties']) or
                        (row == ['type', 'ecosystem', 'vendor', 'name', 'version', 'license', 'note', 'tag', 'pu_num'])):
                    continue
                if len(row) == 7:
                    extra_properties = json.loads(row[6]) if row[6] else {}
                elif len(row) == 9:
                    extra_properties = {}
                else:
                    if row:
                        print("ERROR: invalid row: {}".format(row))
                    continue
                key = "{}:{}:{}:{}:{}:{}".format(row[0], row[1],row[2], row[3], row[4], row[5])
                if key not in done:
                    self.add_component(row[0], row[1],row[2], row[3], row[4], row[5], extra_properties=extra_properties)
                    done.add(key)

    def get_lines(self):
        # For unit tests
        lines = []
        rows = [c.row() for c in self.components]
        rows.sort()
        for row in rows:
            lines.append(','.join('' if not x else str(x) for x in row))
        return lines


def simple_progress_bar(iteration, total, label='Progress: '):
    """
    Example usage:
        from sca_tool_common import simple_progress_bar

        for i in range(total):
            simple_progress_bar((i+1), 100, label='Processing blah: ')
            time.sleep(0.10)
    """
    if iteration and total:
        percent = 100 * (iteration / float(total))
        print("\r{}{:.2f}%   ".format(label, percent), end = "")
        if percent == 100.0:
            print("\n")


def safe_str(s):
    if s:
        return str(s).strip()[:MAX_STR_LEN].strip()
    return ""


def get_sca_tool_version(version_path):
    try:
        with open(str(version_path), "r") as f:
            return f.read().strip()
    except Exception as e:
        print("ERROR: couldn't get sca tool version from \"{}\" ({})".format(version_path, e))
    return "-"
